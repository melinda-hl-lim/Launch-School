require 'pry'

class Cipher
  # Handy constants to reference some ordinal numbers we need
  UPPER_A = 65
  UPPER_Z = 90
  LOWER_A = 97
  LOWER_Z = 122

  def self.rotate(str, step)
    # Convert the string into each character's Integer ordinals
    char_ascii = str.chars.map(&:ord)

    # Increment each character's ordinal accordingly
    char_ascii.map! do |ord|
      letter?(ord) ? increment_stepwise(ord, step) : ord
    end

    # Reformat the array of incremented ordinals back into a string
    char_ascii.map(&:chr).join("")
  end

  def self.letter?(ord)
    (UPPER_A..UPPER_Z).cover?(ord) || (LOWER_A..LOWER_Z).cover?(ord)
  end

  def self.lowercase?(ord)
    (LOWER_A..LOWER_Z).cover?(ord)
  end

  def self.edge_letter?(ord)
    ord == UPPER_Z || ord == LOWER_Z
  end

  def self.increment_stepwise(ord, total)
    step = 0

    while step < total
      if edge_letter?(ord)
        ord = lowercase?(ord) ? LOWER_A : UPPER_A
      else
        ord += 1
      end
      step += 1
    end

    ord
  end
end
